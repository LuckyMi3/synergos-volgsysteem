export default function AdminLocksPage() {
  return <h2 style={{ marginTop: 0 }}>Lock/Unlock</h2>;
}