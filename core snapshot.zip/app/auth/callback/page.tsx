export default function AuthCallbackPage() {
  return (
    <div style={{ padding: 40 }}>
      Authenticatie via e-mail (magic link) is tijdelijk uitgeschakeld.
    </div>
  );
}
