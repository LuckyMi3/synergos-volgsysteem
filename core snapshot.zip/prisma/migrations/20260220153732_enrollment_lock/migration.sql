-- AlterTable
ALTER TABLE "Enrollment" ADD COLUMN     "assessmentLocked" BOOLEAN NOT NULL DEFAULT false;
