# Architectuur Overzicht

## Rollen
- STUDENT
- TEACHER
- ADMIN

Role preview bestaat via query param (?preview=1&asRole=student) maar is geen echte auth.

## Kernstructuur

User
- Heeft role
- Heeft enrollments
- Heeft assessments (als student)
- Heeft teacherScores / teacherReviews (als docent)

Cohort
- Is een uitvoering
- Heeft enrollments

Enrollment
- Verbindt User ↔ Cohort
- Bevat assessmentLocked boolean

Assessment
- 1 per student per rubricKey per moment
- Bevat scores (student)
- Bevat teacherScores (docent per vraag)
- Bevat teacherReviews (publicatie laag)

## Lock logica
Lock zit op:
Enrollment.assessmentLocked

Niet op Assessment zelf.

## Deploy strategie
- Vercel build: alleen npm run build
- Prisma generate via postinstall
- Migrations handmatig

Assessment
- studentId
- rubricKey
- moment
- submittedAt (nullable)