# Synergos Volgsysteem – STATUS

## Huidige versie
v1.42

## Live omgeving
Vercel – Production branch: main

## Wat is stabiel
- Student view werkt
- Docent view werkt
- Admin basis werkt
- Role preview alleen zichtbaar via ?preview=1
- Tools pagina bestaat (placeholder met 3 blokken)
- Deploy pipeline stabiel (geen migrations in build)

## Wat is in ontwikkeling
- Admin Unlock tool (eerste echte tool)
- Import functionaliteit (later)

## Belangrijke keuzes
- Migrations NIET automatisch in Vercel build
- UI deploys moeten altijd groen zijn
- Schema wijzigingen bewust handmatig uitvoeren
- directUrl toegevoegd in Prisma voor migrations

## Volgende prioriteiten
1. Unlock tool afronden
2. Admin overzicht verbeteren
3. Imports V1 (studenten eerst)
4. Docent "preview als student" netjes integreren

## Bekende aandachtspunten
- Email duplicatie bij studenten (CRM issue)
- Rollenstructuur moet later via echte auth lopen
- Unlock moet netjes omgaan met TeacherReview status

### v1.41 – Student inleverfunctie

- Assessment heeft veld `submittedAt`
- Student kan meetmoment inleveren via knop
- Na inleveren:
  - sliders disabled
  - saveScore geblokkeerd
  - status toont ingeleverd op datum/tijd
- Admin unlock nog te bouwen
